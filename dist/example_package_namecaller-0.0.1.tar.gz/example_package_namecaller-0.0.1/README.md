# namecaller.py

* simple python script to check how to easlily install and run a random python script in windows powershell or command shell with requirements.
* installation ???
* instructictions:
```
usage: namecaller.py [-h] [--version] [name]

PS> python namecaller.py piet, calls out piet

positional arguments:
  name

options:
  -h, --help  show this help message and exit
  --version   show program's version number and exit
```
